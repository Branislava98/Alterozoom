#ifndef ARPCMODBUSRTUSLAVE_H
#define ARPCMODBUSRTUSLAVE_H

#include "ARpcModbusRTUSerial.h"

typedef int8_t BoolRead(uint16_t);
typedef bool BoolWrite(uint16_t,bool);
typedef int32_t WordRead(uint16_t);
typedef bool WordWrite(uint16_t,uint16_t);

class ARpcModbusRTUSlave
{
public:
	ARpcModbusRTUSlave(uint8_t *buf,uint16_t bufSize,uint16_t responseDelay=0);
	void configureCoils(uint16_t numCoils,BoolRead coilRead,BoolWrite coilWrite);
	void configureDiscreteInputs(uint16_t numDiscreteInputs,BoolRead discreteInputRead);
	void configureHoldingRegisters(uint16_t numHoldingRegisters,WordRead holdingRegisterRead,
		WordWrite holdingRegisterWrite);
	void configureInputRegisters(uint16_t numInputRegisters,WordRead inputRegisterRead);
	void begin(uint8_t id,uint32_t baud,uint8_t config);//config = 0x06
	void poll();

private:
	void processBoolRead(uint16_t numBools,BoolRead boolRead);
	void processWordRead(uint16_t numWords,WordRead wordRead);
	void exceptionResponse(uint8_t code);
	void write(uint8_t len);
	uint16_t crc16(uint8_t len);
	static uint16_t div8RndUp(uint16_t value);
	static uint16_t bytesToWord(uint8_t high,uint8_t low);

private:
	struct ARpcModbusRTUSerial _serial;
	uint8_t mId;
	uint8_t *mBuf;
	uint16_t mBufSize;
	uint32_t mCharTimeout;
	uint32_t mFrameTimeout;
	uint16_t mResponseDelay;
	uint16_t mNumCoils;
	uint16_t mNumDiscreteInputs;
	uint16_t mNumHoldingRegisters;
	uint16_t mNumInputRegisters;
	BoolRead *mCoilRead;
	BoolRead *mDiscreteInputRead;
	WordRead *mHoldingRegisterRead;
	WordRead *mInputRegisterRead;
	BoolWrite *mCoilWrite;
	WordWrite *mHoldingRegisterWrite;
};

#endif
