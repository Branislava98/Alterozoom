#include "ARpcModbusRTUSlave.h"
#include <Arduino.h>

//#define lowByte(w) ((uint8_t) ((w) & 0xff))
//#define highByte(w) ((uint8_t) ((w) >> 8))

//#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
//#define bitSet(value, bit) ((value) |= (1UL << (bit)))
//#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
//#define bitToggle(value, bit) ((value) ^= (1UL << (bit)))
//#define bitWrite(value, bit, bitvalue) ((bitvalue) ? bitSet(value, bit) : bitClear(value, bit))

ARpcModbusRTUSlave::ARpcModbusRTUSlave(uint8_t *buf,uint16_t bufSize,uint16_t responseDelay)
{
	mBuf=buf;
	mBufSize=bufSize;
	mResponseDelay=responseDelay;
	mNumCoils=0;
	mNumDiscreteInputs=0;
	mNumHoldingRegisters=0;
	mNumInputRegisters=0;
}

void ARpcModbusRTUSlave::configureCoils(uint16_t numCoils,BoolRead coilRead,BoolWrite coilWrite)
{
	mNumCoils=numCoils;
	mCoilRead=coilRead;
	mCoilWrite=coilWrite;
}

void ARpcModbusRTUSlave::configureDiscreteInputs(uint16_t numDiscreteInputs,BoolRead discreteInputRead)
{
	mNumDiscreteInputs=numDiscreteInputs;
	mDiscreteInputRead=discreteInputRead;
}

void ARpcModbusRTUSlave::configureHoldingRegisters(uint16_t numHoldingRegisters,WordRead holdingRegisterRead,WordWrite holdingRegisterWrite)
{
	mNumHoldingRegisters=numHoldingRegisters;
	mHoldingRegisterRead=holdingRegisterRead;
	mHoldingRegisterWrite=holdingRegisterWrite;
}

void ARpcModbusRTUSlave::configureInputRegisters(uint16_t numInputRegisters,WordRead inputRegisterRead)
{
	mNumInputRegisters=numInputRegisters;
	mInputRegisterRead=inputRegisterRead;
}

void ARpcModbusRTUSlave::begin(uint8_t id,uint32_t baud,uint8_t config)
{
	mId=id;
	uint32_t startTime=micros();
	if(baud>19200)
	{
		mCharTimeout=750;
		mFrameTimeout=1750;
	}
	else if(config==0x2E||config==0x3E)
	{
		mCharTimeout=18000000/baud;
		mFrameTimeout=42000000/baud;
	}
	else if(config==0x0E||config==0x26||config==0x36)
	{
		mCharTimeout=16500000/baud;
		mFrameTimeout=38500000/baud;
	}
	else
	{
		mCharTimeout=15000000/baud;
		mFrameTimeout=35000000/baud;
	}
	do
	{
		if(_serial.serialAvailable()>0)
		{
			startTime=micros();
			_serial.serialRead();
		}
	}
	while((micros()-startTime)<mFrameTimeout);
}

void ARpcModbusRTUSlave::poll()
{
	if(_serial.serialAvailable())
	{
		uint8_t i=0;
		uint32_t startTime;
		do
		{
			if(_serial.serialAvailable())
			{
				startTime=micros();
				mBuf[i]=_serial.serialRead();
				i++;
			}
		}
		while((micros()-startTime)<mCharTimeout&&i<mBufSize);
		while((micros()-startTime)<mFrameTimeout);
		if(!_serial.serialAvailable()&&(mBuf[0]==mId||mBuf[0]==0)&&
			crc16(i-2)==bytesToWord(mBuf[i-1],mBuf[i-2]))
		{
			switch(mBuf[1])
			{
			case 1: /* Read Coils */
				ModbusRTUSlave_processBoolRead(t,mNumCoils,mCoilRead);
				break;
			case 2: /* Read Discrete Inputs */
				ModbusRTUSlave_processBoolRead(t,mNumDiscreteInputs,mDiscreteInputRead);
				break;
			case 3: /* Read Holding Registers */
				ModbusRTUSlave_processWordRead(t,mNumHoldingRegisters,mHoldingRegisterRead);
				break;
			case 4: /* Read Input Registers */
				ModbusRTUSlave_processWordRead(t,mNumInputRegisters,mInputRegisterRead);
				break;
			case 5: /* Write Single Coil */
			{
				uint16_t address=bytesToWord(mBuf[2],mBuf[3]);
				uint16_t value=bytesToWord(mBuf[4],mBuf[5]);
				if(value!=0&&value!=0xFF00)
					exceptionResponse(3);
				else if(address>=mNumCoils)
					exceptionResponse(2);
				else if(!mCoilWrite(address,highByte(value)))
					exceptionResponse(4);
				else write(6);
			}
				break;
			case 6: /* Write Single Holding Register */
			{
				uint16_t address=bytesToWord(mBuf[2],mBuf[3]);
				uint16_t value=bytesToWord(mBuf[4],mBuf[5]);
				if(address>=mNumHoldingRegisters)
					exceptionResponse(2);
				else if(!mHoldingRegisterWrite(address,value))
					exceptionResponse(4);
				else write(6);
			}
				break;
			case 15: /* Write Multiple Coils */
			{
				uint16_t startAddress=bytesToWord(mBuf[2],mBuf[3]);
				uint16_t quantity=bytesToWord(mBuf[4],mBuf[5]);
				if(quantity==0||quantity>((mBufSize-10)<<3)||mBuf[6]!=div8RndUp(quantity))
					exceptionResponse(3);
				else if((startAddress+quantity)>mNumCoils)
					exceptionResponse(2);
				else
				{
					for(uint8_t j=0;j<quantity;j++)
					{
						if(!mCoilWrite(startAddress+j,bitRead(mBuf[7+(j>>3)],j&7)))
						{
							exceptionResponse(4);
							return;
						}
					}
					write(6);
				}
			}
				break;
			case 16: /* Write Multiple Holding Registers */
			{
				uint16_t startAddress=bytesToWord(mBuf[2],mBuf[3]);
				uint16_t quantity=bytesToWord(mBuf[4],mBuf[5]);
				if(quantity==0||quantity>((mBufSize-10)>>1)||mBuf[6]!=(quantity*2))
					exceptionResponse(3);
				else if(startAddress+quantity>mNumHoldingRegisters)
					exceptionResponse(2);
				else
				{
					for(uint8_t j=0;j<quantity;j++)
					{
						if(!mHoldingRegisterWrite(startAddress+j,bytesToWord(mBuf[j*2+7],mBuf[j*2+8])))
						{
							exceptionResponse(4);
							return;
						}
					}
					write(6);
				}
			}
				break;
			default:
				exceptionResponse(1);
				break;
			}
		}
	}
}

void ARpcModbusRTUSlave::processBoolRead(uint16_t numBools,BoolRead boolRead)
{
	uint16_t startAddress=bytesToWord(mBuf[2],mBuf[3]);
	uint16_t quantity=bytesToWord(mBuf[4],mBuf[5]);
	if(quantity==0||quantity>((mBufSize-6)<<3))
		ModbusRTUSlave_exceptionResponse(t,3);
	else if((startAddress+quantity)>numBools)
		ModbusRTUSlave_exceptionResponse(t,2);
	else
	{
		for(uint8_t j=0;j<quantity;j++)
		{
			int8_t value=boolRead(startAddress+j);
			if(value<0)
			{
				ModbusRTUSlave_exceptionResponse(t,4);
				return;
			}
			bitWrite(mBuf[3+(j>>3)],j&7,value);
		}
		mBuf[2]=div8RndUp(quantity);
		write(3+mBuf[2]);
	}
}

void ARpcModbusRTUSlave::processWordRead(uint16_t numWords,WordRead wordRead)
{
	uint16_t startAddress=bytesToWord(mBuf[2],mBuf[3]);
	uint16_t quantity=bytesToWord(mBuf[4],mBuf[5]);
	if(quantity==0||quantity>((mBufSize-6)>>1))
		ModbusRTUSlave_exceptionResponse(t,3);
	else if((startAddress+quantity)>numWords)
		ModbusRTUSlave_exceptionResponse(t,2);
	else
	{
		for(uint8_t j=0;j<quantity;j++)
		{
			int32_t value=wordRead(startAddress+j);
			if(value<0)
			{
				ModbusRTUSlave_exceptionResponse(t,4);
				return;
			}
			mBuf[3+(j<<1)]=highByte(value);
			mBuf[4+(j<<1)]=lowByte(value);
		}
		mBuf[2]=quantity<<1;
		write(3+mBuf[2]);
	}
}

void ARpcModbusRTUSlave::exceptionResponse(uint8_t code)
{
	mBuf[1]|=0x80;
	mBuf[2]=code;
	write(3);
}

void ARpcModbusRTUSlave::write(uint8_t len)
{
	delay(mResponseDelay);
	if(mBuf[0]!=0)
	{
		uint16_t crc=crc16(len);
		mBuf[len]=lowByte(crc);
		mBuf[len+1]=highByte(crc);
		_serial.rs485SetTransmit(1);
		_serial.serialWrite(mBuf,len+2);
		_serial.rs485SetTransmit(0);
	}
	delay(mResponseDelay);
}

uint16_t ARpcModbusRTUSlave::crc16(uint8_t len)
{
	uint16_t crc=0xFFFF;
	for(uint8_t i=0;i<len;i++)
	{
		crc^=(uint16_t)mBuf[i];
		for(uint8_t j=0;j<8;j++)
		{
			uint8_t lsb=crc&1;
			crc>>=1;
			if(lsb!=0)
			{
				crc^=0xA001;
			}
		}
	}
	return crc;
}

uint16_t ARpcModbusRTUSlave::div8RndUp(uint16_t value)
{
	return (value+7)>>3;
}

uint16_t ARpcModbusRTUSlave::bytesToWord(uint8_t high,uint8_t low)
{
	return (high<<8)|low;
}
