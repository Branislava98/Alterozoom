#ifndef ARPCMODBUSRTUMASTER_H
#define ARPCMODBUSRTUMASTER_H

#include "ARpcModbusRTUSerial.h"

#ifndef RTU_BROADCAST_ADDRESS
#define RTU_BROADCAST_ADDRESS 0x00
#endif

//TODO different frame and char timeouts
class ARpcModbusRTUMaster
{
private:
	typedef struct
	{
		uint16_t len;
		uint8_t id;
		uint8_t cmd;
		uint8_t payload[0];
		uint16_t cs;
	}__attribute__ ((packed)) sRtuPacketHeader_t, *pRtuPacketHeader_t;

	typedef enum
	{
		eRTU_NO_ERROR=0x0,
		eRTU_EXCEPTION_ILLEGAL_FUNCTION=0x01,
		eRTU_EXCEPTION_ILLEGAL_DATA_ADDRESS,
		eRTU_EXCEPTION_ILLEGAL_DATA_VALUE,
		eRTU_EXCEPTION_SLAVE_FAILURE,
		eRTU_EXCEPTION_CRC_ERROR = 0x08,
		eRTU_RECV_ERROR,
		eRTU_MEMORY_ERROR,
		eRTU_ID_ERROR
	}eRtuStatusExceptionCode_t;

	typedef enum
	{
		eCMD_READ_COILS=0x01,
		eCMD_READ_DISCRETE=0x02,
		eCMD_READ_HOLDING=0x03,
		eCMD_READ_INPUT=0x04,
		eCMD_WRITE_COILS=0x05,
		eCMD_WRITE_HOLDING=0x06,
		eCMD_WRITE_MULTI_COILS=0x0F,
		eCMD_WRITE_MULTI_HOLDING=0x10
	}eFunctionCommand_t;

public:
	/**
	 * @brief DFRobot_RTU abstract class constructor. Construct serial port.
	 * @param s: serial communication functions
	 */
	ARpcModbusRTUMaster(ARpcModbusRTUSerial *s);
	~ARpcModbusRTUMaster(){}

	/**
	* @brief error
	* @return Exception code:
	* @n      0 : sucess.
	* @n      1 or eRTU_EXCEPTION_ILLEGAL_FUNCTION : Illegal function.
	* @n      2 or eRTU_EXCEPTION_ILLEGAL_DATA_ADDRESS: Illegal data address.
	* @n      3 or eRTU_EXCEPTION_ILLEGAL_DATA_VALUE:  Illegal data value.
	* @n      4 or eRTU_EXCEPTION_SLAVE_FAILURE:  Slave failure.
	* @n      8 or eRTU_EXCEPTION_CRC_ERROR:  CRC check error.
	* @n      9 or eRTU_RECV_ERROR:  Receive packet error.
	* @n      10 or eRTU_MEMORY_ERROR: Memory error.
	* @n      11 or eRTU_ID_ERROR: broadcast address or error ID
	 */
	eRtuStatusExceptionCode_t error();

	/**
	* @brief Set receive timeout time, unit ms.
	* @param timeout: receive timeout time, unit ms, default 100mss.
	*/
	void setTimeoutTimeMs(uint32_t timeout=100);

	/**
	* @brief Read a coil (0x01 function code).
	* @param id:  modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: coil address.
	* @param val: coil value (out)
	* @return false if there was errors (call error() to get last error)
	*/
	bool readCoil(uint8_t id,uint16_t reg,bool &val);

	/**
	* @brief Read a discrete input (0x02 function code).
	* @param id:  modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: discrete input address.
	* @param val: discrete input value (out)
	* @return false if there was errors (call error() to get last error)
	*/
	bool readDiscreteInput(uint8_t id,uint16_t reg,bool &val);

	/**
	* @brief Read a holding register (0x03 function code).
	* @param id: modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: holding register address.
	* @param val: holding register value (out)
	* @return false if there was errors (call error() to get last error)
	*/
	bool readHoldingRegister(uint8_t id,uint16_t reg,uint16_t &val);

	/**
	* @brief Read a input register (0x04 function code).
	* @param id:  modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: input register address.
	* @param val: input register value (out)
	* @return false if there was errors (call error() to get last error)
	*/
	bool readInputRegister(uint8_t id,uint16_t reg,uint16_t &val);

	/**
	* @brief Write a coil (0x05 function code).
	* @param id: modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: coil address.
	* @param val: the value of the register value which will be write.
	* @return false if there was errors (call error() to get last error)
	*/
	bool writeCoil(uint8_t id,uint16_t reg,bool val);

	/**
	* @brief Write a holding register (0x06 function code).
	* @param id:  modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: holding register address.
	* @param val: the value of the register value which will be write.
	* @return false if there was errors (call error() to get last error)
	*/
	bool writeHoldingRegister(uint8_t id,uint16_t reg,uint16_t val);

	/**
	* @brief Read multiple coils (0x01 function code).
	* @param id: modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: first coil address.
	* @param count: number of coils.
	* @param data: data pointer for values.
	* @return false if there was errors (call error() to get last error)
	*/
	bool readMultiCoils(uint8_t id,uint16_t reg,uint16_t count,bool *data);

	/**
	* @brief Read multiple discrete inputs (0x02 function code).
	* @param id: modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: first discrete input address.
	* @param count: Number of discrete inputs.
	* @param data: data pointer for values.
	* @return false if there was errors (call error() to get last error)
	*/
	bool readMultiDiscreteInputs(uint8_t id,uint16_t reg,uint16_t count,bool *data);

	/**
	* @brief Read multiple holding registers (0x03 function code).
	* @param id: modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: first holding register address.
	* @param count: holding registers count.
	* @param data: data pointer for values.
	* @return false if there was errors (call error() to get last error)
	*/
	bool readMultiHoldingRegisters(uint8_t id,uint16_t reg,uint16_t count,uint16_t *data);

	/**
	* @brief Read multiple input registers (0x04 function code).
	* @param id: modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: first input register address.
	* @param data: data pointer for values.
	* @param count: input registers count.
	* @return false if there was errors (call error() to get last error)
	*/
	bool readMultiInputRegisters(uint8_t id,uint16_t reg,uint16_t count,uint16_t *data);

	/**
	* @brief Write multiple coils (0x0f function code).
	* @param id: modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: first coil address.
	* @param count: numbers of coils.
	* @param data: coils values.
	* @return false if there was errors (call error() to get last error)
	*/
	//bool writeMultiCoils(uint8_t id,uint16_t reg,uint16_t count,bool *data);

	/**
	* @brief Write multiple Holding Registers (0x10 function code).
	* @param id: modbus device ID. Range: 0x00 ~ 0xF7(0~247), 0x00 is broadcast address,
	* which all slaves will process broadcast packets, but will not answer.
	* @param reg: first holding register address.
	* @param count: numbers of holding registers.
	* @param data: values.
	* @return false if there was errors (call error() to get last error)
	*/
	//bool writeMultiHoldingRegisters(uint8_t id,uint16_t reg,uint16_t count,uint16_t *data);

private:
	void clearRecvBuffer();
	uint16_t calculateCRC(uint8_t *data,uint8_t len);
	pRtuPacketHeader_t packed(uint8_t id,eFunctionCommand_t cmd,void *data,uint16_t size);
	pRtuPacketHeader_t packed(uint8_t id,uint8_t cmd,void *data,uint16_t size);
	void sendPackage(pRtuPacketHeader_t header);
	pRtuPacketHeader_t recvAndParsePackage(uint8_t id,uint8_t cmd,uint16_t data);
		//modifies mError

private:
	uint32_t mTimeout;
	eRtuStatusExceptionCode_t mError;
	ARpcModbusRTUSerial *mSerial;
};
#endif
