#include "ARpcTimeSync.h"
#include <Arduino.h>

static const uint16_t count=10;

ARpcTimeSync::ARpcTimeSync(ARpcRealDeviceMessageDispatch *d)
	:ARpcITimeSync(d)
{
	state=IDLE;
	delta=0;
	startMillis=new uint32_t[count];
	endMillis=new uint32_t[count];
	unixTimes=new uint64_t[count];
}

ARpcTimeSync::~ARpcTimeSync()
{
	delete[] startMillis;
	delete[] endMillis;
	delete[] unixTimes;
}

void ARpcTimeSync::start()
{
	if(state==SYNC)return;
	state=SYNC;
	delta=0;
	currIndex=0;
	writeTssMsg(0);
	startMillis[0]=millis();
}

void ARpcTimeSync::stop()
{
	state=IDLE;
}

uint64_t ARpcTimeSync::timeDelta()
{
	return delta;
}

uint64_t ARpcTimeSync::currentUnixTimeMSec()
{
	uint64_t r=delta;
	uint64_t m=millis();
	return r+m;
}

void ARpcTimeSync::onTseMsg(const uint16_t &packNum,const uint64_t &unixTimeMSec)
{
	if(packNum!=currIndex)
	{
		state=IDLE;
		return;
	}
	endMillis[currIndex]=millis();
	unixTimes[currIndex]=unixTimeMSec;
	++currIndex;
	if(currIndex==10)
	{
		uint64_t Di=0;
		delta=0;
		for(int i=0;i<10;++i)
		{
			Di=unixTimes[i]-(((uint64_t)startMillis[i]+(uint64_t)endMillis[i])>>1);
			delta+=Di;
		}
		delta/=10;
		state=DONE;
		return;
	}
	else
	{
		writeTssMsg((uint16_t)currIndex);
		startMillis[currIndex]=millis();
	}
}
