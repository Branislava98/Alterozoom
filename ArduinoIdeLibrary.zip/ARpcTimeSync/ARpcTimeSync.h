#ifndef ARPCTIMESYNC_H
#define ARPCTIMESYNC_H

#include <ARpcITimeSync.h>

class ARpcTimeSync
	:public ARpcITimeSync
{
public:
	explicit ARpcTimeSync(ARpcRealDeviceMessageDispatch *d);
	~ARpcTimeSync();
	void start();
	void stop();
	uint64_t timeDelta();
	uint64_t currentUnixTimeMSec();
	virtual void onTseMsg(const uint16_t &packNum,const uint64_t &unixTimeMSec)override;

private:
	enum State
	{
		IDLE,
		SYNC,
		DONE
	}state;
	uint16_t currIndex;
	uint32_t *startMillis;
	uint32_t *endMillis;
	uint64_t *unixTimes;
	uint64_t delta;
};

#endif // ARPCTIMESYNC_H
