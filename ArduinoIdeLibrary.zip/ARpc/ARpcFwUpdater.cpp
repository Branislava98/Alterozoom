/*******************************************
Copyright 2022 OOO "LMS"

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.*/

#include "ARpcFwUpdater.h"

ARpcFwUpdater::ARpcFwUpdater(ARpcIFwUpdateCallback *c)
{
	cb=c;
	mFwSize=0;
	updateInProcess=false;
	currentOffset=0;
}

bool ARpcFwUpdater::startFwUpdate(const ARpcUuid &hwTypeId,uint64_t fwSize,
	const char **args,unsigned int *sizes,unsigned char argsCount)
{
	if(updateInProcess||fwSize==0||!cb)return false;
	if(!cb->startFwUpdate(hwTypeId,fwSize,args,sizes,argsCount))
		return false;
	updateInProcess=true;
	mFwSize=fwSize;
	currentOffset=0;
	return true;
}

bool ARpcFwUpdater::writeFwPart(const uint8_t *data,uint64_t offset,uint64_t size)
{
	if(!updateInProcess)return false;
	if(offset!=currentOffset||!cb->writeFwPart(data,size))
	{
		abortUpdate();
		return false;
	}
	currentOffset+=size;
	return true;
}

bool ARpcFwUpdater::confirmUpdate()
{
	if(!updateInProcess)return false;
	if(!cb->confirmUpdate())
	{
		abortUpdate();
		return false;
	}
	return true;
}

void ARpcFwUpdater::abortUpdate()
{
	if(cb)cb->updateAborted();
	updateInProcess=false;
	currentOffset=0;
}

void ARpcFwUpdater::restartDevice()
{
	if(cb)cb->restartDevice();
}
