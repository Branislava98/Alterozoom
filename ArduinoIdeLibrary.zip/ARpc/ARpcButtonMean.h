#ifndef ARPCBUTTONMEAN_H
#define ARPCBUTTONMEAN_H

#include <stdint.h>

class ARpcIButtonMeanCallback
{
public:
	virtual ~ARpcIButtonMeanCallback(){}
	virtual void onButtonCalcComplete(bool on)=0;
};

/**
 * Устранение дребезга кнопки путем усреднения нескольких операций чтения значения цифрового пина
*/
class ARpcButtonMean
{
public:
	explicit ARpcButtonMean(unsigned int meanCount,ARpcIButtonMeanCallback *cb);
	~ARpcButtonMean();
	void pushVal(bool on);
	int value();
	void reset(bool on);

private:
	unsigned int valuesCount,bytesCount,currIndex,ringIndex;
	bool currValue;
	uint8_t *arr;
	ARpcIButtonMeanCallback *callback;
};

#endif // ARPCBUTTONMEAN_H
