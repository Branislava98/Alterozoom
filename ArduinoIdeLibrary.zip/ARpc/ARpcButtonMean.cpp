#include "ARpcButtonMean.h"
#include <Arduino.h>

ARpcButtonMean::ARpcButtonMean(unsigned int meanCount,ARpcIButtonMeanCallback *cb)
{
	callback=cb;
	currIndex=0;
	currValue=false;
	valuesCount=meanCount;
	if(valuesCount==0)
		valuesCount=1;
	bytesCount=((valuesCount-1)>>3)+1;
	arr=new uint8_t[bytesCount];
	for(unsigned int i=0;i<bytesCount;++i)
		arr[i]=0;
}

ARpcButtonMean::~ARpcButtonMean()
{
	delete[] arr;
}

void ARpcButtonMean::pushVal(bool on)
{
	unsigned int byteIndex=currIndex>>3;
	unsigned int byteOffset=currIndex-(byteIndex<<3);
	if(on)
		arr[byteIndex]|=(uint8_t)(0x1<<byteOffset);
	else arr[byteIndex]&=~(uint8_t)(0x1<<byteOffset);
	++currIndex;
	unsigned int v=0,bitIndex=0;
	for(unsigned int i=0;i<valuesCount;++i)
	{
		byteIndex=i>>3;
		bitIndex=i-(byteIndex<<3);
		v+=(arr[byteIndex]>>bitIndex)&0x1;
	}
	if(currIndex==valuesCount)
		currIndex=0;
	if(currValue&&v<=(valuesCount>>2))//more then 3/4 are 0
	{
		currValue=false;
		if(callback)
			callback->onButtonCalcComplete(false);
	}
	if(!currValue&&v>=valuesCount-(valuesCount>>2))//more then 3/4 are 1
	{
		currValue=true;
		if(callback)
			callback->onButtonCalcComplete(true);
	}
}

int ARpcButtonMean::value()
{
	return currValue;
}

void ARpcButtonMean::reset(bool on)
{
	currValue=on;
	unsigned int bytesCount=((valuesCount-1)>>3)+1;
	for(unsigned int i=0;i<bytesCount;++i)
		arr[i]=on?0xff:0;
}
