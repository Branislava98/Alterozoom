#include "ARpcITimeSync.h"
#include "ARpcRealDeviceMessageDispatch.h"

ARpcITimeSync::ARpcITimeSync(ARpcRealDeviceMessageDispatch *d)
{
	disp=d;
}

void ARpcITimeSync::writeTssMsg(unsigned short packNum)
{
	ARpcStreamWriter *w=disp->writer();
	w->beginWriteMsg();
	w->writeArgNoEscape("tss");
	w->writeArg((const char*)&packNum,sizeof(packNum));
	w->endWriteMsg();
}
