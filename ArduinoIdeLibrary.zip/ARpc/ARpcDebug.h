#ifndef ARPCDEBUG_H
#define ARPCDEBUG_H

#include "ARpcArduStrHlp.h"

class IARpcDebug
{
public:
	virtual void debug(const char *a1,const char *a2=0,const char *a3=0,const char *a4=0)=0;
};

extern IARpcDebug *arpcDebug;

#endif // ARPCDEBUG_H
