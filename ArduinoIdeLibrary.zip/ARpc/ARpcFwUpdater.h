/*******************************************
Copyright 2022 OOO "LMS"

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.*/

#ifndef ARPCFWUPDATER_H
#define ARPCFWUPDATER_H

#include "ARpcIFwUpdateCallback.h"
#include "ARpcUuid.h"

class ARpcFwUpdater
{
public:
	explicit ARpcFwUpdater(ARpcIFwUpdateCallback *c);
	bool startFwUpdate(const ARpcUuid &hwTypeId,uint64_t fwSize,
		const char **args,unsigned int *sizes,unsigned char argsCount);
	bool writeFwPart(const uint8_t *data,uint64_t offset,uint64_t size);
	bool confirmUpdate();
	void abortUpdate();
	void restartDevice();

private:
	bool updateInProcess;
	ARpcIFwUpdateCallback *cb;
	uint64_t mFwSize;
	uint64_t currentOffset;
};

#endif // ARPCFWUPDATER_H
