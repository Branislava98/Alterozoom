#include <Arduino.h>
#include <ARpcDevice.h>
#include <WiFiClient.h>
#include <WiFiServer.h>
#include <WiFiUdp.h>
#include <ARpcSrvReady.h>

#ifdef ESP8266
#pragma GCC warning "ESP8266 MCU detected"
#include <ESP8266WiFi.h>
#elif defined ESP32
#pragma GCC warning "ESP32 MCU detected"
#include <WiFi.h>
#else
#error "Unsupported MCU"
#endif

class ARpcWiFiDevice
	:public ARpcDevice
{
	class NetWriteCb
		:public ARpcIWriteCallback
	{
	public:
		explicit NetWriteCb(ARpcWiFiDevice *d);
		virtual void writeData(const char *data,unsigned long sz);
		virtual void writeStr(const char *str);
		virtual void writeStr(const __FlashStringHelper *str);

	private:
		ARpcWiFiDevice *dev;
	};

	class SrvReadyCb
		:public ARpcISrvReadyCallback
	{
	public:
		explicit SrvReadyCb(ARpcWiFiDevice *d);
		virtual void processSrvReadyMsg(const ARpcUuid &srvId,const char *srvName);

	private:
		ARpcWiFiDevice *dev;
	};

public:
	enum IotSrvState
	{
		IOT_STOPPED,
		IOT_WAIT_WIFI,
		IOT_IDLE,
		IOT_CONNECTING,
		IOT_CONNECTED
	};

	class IWiFiEventsCb
	{
	public:
		virtual void onWiFiConnected();
		virtual void onWiFiDisconnected();
		virtual bool onServerFound(const ARpcUuid &srvId,const char *srvName);
		virtual void onServerConnected();
		virtual void onServerDisconnected();
		virtual void onServerConnectionFailed();
		virtual void onSyncTimeout();
	};

public:
	explicit ARpcWiFiDevice(unsigned long devBufSize,unsigned long bcastBufSize,
		const ARpcUuid *deviceId,const char *deviceName);
	void zeroSsidKey();
	void setDebugOutputFunction(void (*f)(const char*));
	void setEventsCb(IWiFiEventsCb *cb);
	void setup();
	void loop();
	void reconnectWiFi();//call when essid and key changed
	void onSyncMsg();//call when sync msg appeared
	bool isConnected();
	void connectTo(IPAddress ip);
	void connectTo(const char *host);
	IotSrvState iotState();

private:
	void checkWiFi();
	void checkBCastCli();
	void checkWiFiClient();
	void onWaitSyncTimer();
	void debug(const String &str);
	void debug(const char *str);
	void stopWiFi();
//	bool waitForConnected();

public:
	char ssid[33];
	char key[65];
	static const int ssidMaxLen=32;
	static const int keyMaxLen=64;

private:
	static const int port;
	IotSrvState state;
	int syncCounter;
	NetWriteCb cb;
	WiFiServer server;
	WiFiClient client;
	IPAddress bCastSenderIp;
	WiFiUDP bCastCli;
	unsigned long prevSyncMSec,startConnSrvMsec,startConnWiFiMSec;
	SrvReadyCb srvReadyCb;
	ARpcSrvReady srvReadyParser;
	void (*debugInfoFunc)(const char *);
	IWiFiEventsCb *eventsCb;
};
