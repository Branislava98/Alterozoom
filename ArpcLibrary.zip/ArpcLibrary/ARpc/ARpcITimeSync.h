#ifndef ARPCITIMESYNC_H
#define ARPCITIMESYNC_H

class ARpcRealDeviceMessageDispatch;
#include <stdint.h>

class ARpcITimeSync
{
public:
	explicit ARpcITimeSync(ARpcRealDeviceMessageDispatch *d);
	virtual ~ARpcITimeSync(){}
	void writeTssMsg(uint16_t packNum);
	virtual void onTseMsg(const uint16_t &packNum,const uint64_t &unixTimeMSec)=0;

private:
	ARpcRealDeviceMessageDispatch *disp;
};

#endif // ARPCITIMESYNC_H
