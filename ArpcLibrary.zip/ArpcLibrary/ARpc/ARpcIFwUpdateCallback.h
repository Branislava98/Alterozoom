/*******************************************
Copyright 2022 OOO "LMS"

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.*/

#ifndef ARPCIFWUPDATECALLBACK_H
#define ARPCIFWUPDATECALLBACK_H

#include "ARpcUuid.h"
#include <stdint.h>

class ARpcIFwUpdateCallback
{
public:
	virtual ~ARpcIFwUpdateCallback(){}
	virtual bool startFwUpdate(const ARpcUuid &hwTypeId,uint64_t size,
		const char **args,unsigned int *sizes,unsigned char argsCount)=0;
		//return false if device is not ready to begin update
	virtual bool writeFwPart(const uint8_t *data,uint64_t size)=0;
	virtual bool confirmUpdate()=0;
	virtual void updateAborted()=0;
	virtual void restartDevice()=0;
};

#endif // ARPCIFWUPDATECALLBACK_H
