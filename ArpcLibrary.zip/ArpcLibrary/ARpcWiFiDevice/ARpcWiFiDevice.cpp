#include "ARpcWiFiDevice.h"

const int ARpcWiFiDevice::port=4081;
static const unsigned long waitTimerDelta=5000;//msec
static const unsigned long waitConnectedTime=5000;//msec
static const unsigned long waitWiFiTime=5000;//msec
static const int syncCounterMax=3;

ARpcWiFiDevice::ARpcWiFiDevice(unsigned long devBufSize,unsigned long bcastBufSize,
	const ARpcUuid *deviceId,const char *deviceName)
	:ARpcDevice(devBufSize,&cb,deviceId,deviceName)
	,cb(this)
	,server(port)
	,srvReadyCb(this)
	,srvReadyParser(bcastBufSize,&srvReadyCb)
{
	zeroSsidKey();
	state=IOT_STOPPED;
	syncCounter=syncCounterMax;
	debugInfoFunc=0;
	eventsCb=0;
	prevSyncMSec=millis();
	startConnSrvMsec=millis();
	startConnWiFiMSec=millis();
}

void ARpcWiFiDevice::zeroSsidKey()
{
	memset(ssid,0,ssidMaxLen+1);
	memset(key,0,keyMaxLen+1);
}

void ARpcWiFiDevice::setDebugOutputFunction(void (*f)(const char *))
{
	debugInfoFunc=f;
}

void ARpcWiFiDevice::setEventsCb(ARpcWiFiDevice::IWiFiEventsCb *cb)
{
	eventsCb=cb;
}

void ARpcWiFiDevice::setup()
{
	//WiFi.setAutoReconnect(true);
#ifdef ESP8266
	WiFiClient::setDefaultNoDelay(true);
	WiFiClient::setDefaultSync(true);
#endif
	reconnectWiFi();
}

void ARpcWiFiDevice::loop()
{
	checkWiFi();
	checkBCastCli();
	checkWiFiClient();
	if(state==IOT_CONNECTED)
	{
		unsigned long m=millis();
		if((m-prevSyncMSec)>waitTimerDelta)
		{
			prevSyncMSec=m;
			onWaitSyncTimer();
		}
	}
}

void ARpcWiFiDevice::reconnectWiFi()
{
	debug("Reconnect WiFi");
	stopWiFi();
	if(strlen(ssid)==0)return;
	WiFi.begin((const char*)ssid,(const char*)key);
	state=IOT_WAIT_WIFI;
	startConnWiFiMSec=millis();
}

void ARpcWiFiDevice::onSyncMsg()
{
	syncCounter=syncCounterMax;
	prevSyncMSec=millis();
}

bool ARpcWiFiDevice::isConnected()
{
	return state==IOT_CONNECTED;
}

void ARpcWiFiDevice::connectTo(IPAddress ip)
{
	if(state==IOT_CONNECTED||state==IOT_CONNECTING)
	{
		client.stop();
		state=IOT_IDLE;
		if(eventsCb&&state==IOT_CONNECTED)
			eventsCb->onServerDisconnected();
	}
	if(state!=IOT_IDLE)return;
	client.connect(ip,port);
	client.setNoDelay(true);
	state=IOT_CONNECTING;
	startConnSrvMsec=millis();
}

void ARpcWiFiDevice::connectTo(const char *host)
{
	if(state==IOT_CONNECTED||state==IOT_CONNECTING)
	{
		client.stop();
		state=IOT_IDLE;
		if(eventsCb&&state==IOT_CONNECTED)
			eventsCb->onServerDisconnected();
	}
	if(state!=IOT_IDLE)return;
	client.connect(host,port);
	client.setNoDelay(true);
	state=IOT_CONNECTING;
	startConnSrvMsec=millis();
}

ARpcWiFiDevice::IotSrvState ARpcWiFiDevice::iotState()
{
	return state;
}

/*
typedef enum {
    WL_NO_SHIELD        = 255,   // for compatibility with WiFi Shield library
    WL_IDLE_STATUS      = 0,
    WL_NO_SSID_AVAIL    = 1,
    WL_SCAN_COMPLETED   = 2,
    WL_CONNECTED        = 3,
    WL_CONNECT_FAILED   = 4,
    WL_CONNECTION_LOST  = 5,
    WL_DISCONNECTED     = 6
} wl_status_t;
*/

void ARpcWiFiDevice::checkWiFi()
{
	if(WiFi.isConnected())
	{
		if(state!=IOT_WAIT_WIFI)return;
		state=IOT_IDLE;
		server.begin();
		bCastCli.begin(port);
		debug("WiFi connected");
		debug(WiFi.localIP().toString().c_str());
		if(eventsCb)
			eventsCb->onWiFiConnected();
	}
	else
	{
		if(state!=IOT_STOPPED&&state!=IOT_WAIT_WIFI)
			reconnectWiFi();
		else if(state==IOT_WAIT_WIFI&&(millis()-startConnWiFiMSec)>waitWiFiTime)
			reconnectWiFi();
	}
}

void ARpcWiFiDevice::checkBCastCli()
{
	static int sz=0;
	sz=bCastCli.parsePacket();
	if(sz>0)
	{
		bCastSenderIp=bCastCli.remoteIP();
		for(int i=0;i<sz;++i)
		{
			char c=bCastCli.read();
			srvReadyParser.putByte(c);
		}
	}
}

void ARpcWiFiDevice::checkWiFiClient()
{
	if(state==IOT_CONNECTING)
	{
		if(client.connected())
		{
			state=IOT_CONNECTED;
			onSyncMsg();
			if(eventsCb)
				eventsCb->onServerConnected();
		}
		else if((millis()-startConnSrvMsec)>waitConnectedTime)
		{
			client.stop();
			state=IOT_IDLE;
			if(eventsCb)
				eventsCb->onServerConnectionFailed();
		}
	}
	else if(state==IOT_CONNECTED)
	{
		if(client.connected())
		{
			while(client.available())
				putByte((char)client.read());
		}
		else
		{
			state=IOT_IDLE;
			if(eventsCb)
				eventsCb->onServerDisconnected();
			if(!server.hasClient())return;
			client=server.available();
			if(!client.connected())return;
			client.setNoDelay(true);
			debug("Take next pending incoming connection");
			state=IOT_CONNECTED;
			onSyncMsg();
			if(eventsCb)
				eventsCb->onServerConnected();
		}
	}
	else if(state==IOT_IDLE)
	{
		if(!server.hasClient())return;
		client=server.available();
		if(!client.connected())return;
		client.setNoDelay(true);
		debug("Take next pending incoming connection");
		state=IOT_CONNECTED;
		onSyncMsg();
		if(eventsCb)
			eventsCb->onServerConnected();
	}
}

void ARpcWiFiDevice::onWaitSyncTimer()
{
	if(syncCounter>0)
		--syncCounter;
	debug(String("WiFi sync timeout ")+syncCounter);
	if(syncCounter==0&&state==IOT_CONNECTED)
	{
		debug("Server connection timeout");
		client.stop();
		state=IOT_IDLE;
		if(eventsCb)
		{
			eventsCb->onSyncTimeout();
			eventsCb->onServerDisconnected();
		}
		checkWiFiClient();
	}
}

void ARpcWiFiDevice::debug(const String &str)
{
	if(debugInfoFunc)
		debugInfoFunc(str.c_str());
}

void ARpcWiFiDevice::debug(const char *str)
{
	if(debugInfoFunc)
		debugInfoFunc(str);
}

void ARpcWiFiDevice::stopWiFi()
{
	server.stop();
	client.stop();
	WiFi.disconnect();
	state=IOT_STOPPED;
	if(eventsCb)
		eventsCb->onWiFiDisconnected();
}

/*void ARpcWiFiDevice::waitForConnected()
{
	state=IOT_CONNECTING;
	for(int i=0;i<20;++i)
	{
		if(dev->client.connected())
			break;
		delay(100);
	}
	if(client.connected())
	{
		debug("Connected to server");
		connecting=false;
		syncCounter=syncCounterMax;
		prevSyncMSec=millis();
		if(eventsCb)
			eventsCb->onServerConnected();
	}
	else
	{
		client.stop();
	}
}*/

ARpcWiFiDevice::NetWriteCb::NetWriteCb(ARpcWiFiDevice *d)
{
	dev=d;
}

void ARpcWiFiDevice::NetWriteCb::writeData(const char *data,unsigned long sz)
{
	if(dev->client.connected())
		dev->client.write(data,sz);
}

void ARpcWiFiDevice::NetWriteCb::writeStr(const char *str)
{
	if(dev->client.connected())
		dev->client.print(str);
}

void ARpcWiFiDevice::NetWriteCb::writeStr(const __FlashStringHelper *str)
{
	if(dev->client.connected())
		dev->client.print(str);
}

ARpcWiFiDevice::SrvReadyCb::SrvReadyCb(ARpcWiFiDevice *d)
{
	dev=d;
}

void ARpcWiFiDevice::SrvReadyCb::processSrvReadyMsg(const ARpcUuid &srvId,const char *srvName)
{
	if(dev->state!=IOT_IDLE)return;
	dev->debug((String("Server detected|")+dev->bCastSenderIp.toString()+"|"+String(srvName)).c_str());
	if(dev->eventsCb&&!dev->eventsCb->onServerFound(srvId,srvName))
		return;
	dev->debug("Connecting to server...");
	dev->connectTo(dev->bCastSenderIp);
}

void ARpcWiFiDevice::IWiFiEventsCb::onWiFiConnected()
{
}

void ARpcWiFiDevice::IWiFiEventsCb::onWiFiDisconnected()
{
}

bool ARpcWiFiDevice::IWiFiEventsCb::onServerFound(const ARpcUuid &srvId, const char *srvName)
{
	return true;
}

void ARpcWiFiDevice::IWiFiEventsCb::onServerConnected()
{
}

void ARpcWiFiDevice::IWiFiEventsCb::onServerDisconnected()
{
}

void ARpcWiFiDevice::IWiFiEventsCb::onServerConnectionFailed()
{
}

void ARpcWiFiDevice::IWiFiEventsCb::onSyncTimeout()
{
}
