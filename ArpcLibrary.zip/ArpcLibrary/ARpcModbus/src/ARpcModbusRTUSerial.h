#ifndef ARPCMODBUSRTUSERIAL_H
#define ARPCMODBUSRTUSERIAL_H

#include <stdint.h>

struct ARpcModbusRTUSerial
{
	bool (*serialAvailable)(void);
	uint8_t (*serialRead)(void);
	void (*rs485SetTransmit)(bool);
	void (*serialFlush)(void);
	void (*serialWrite)(const uint8_t *s,uint16_t len);
};

#endif // ARPCMODBUSRTUSERIAL_H
