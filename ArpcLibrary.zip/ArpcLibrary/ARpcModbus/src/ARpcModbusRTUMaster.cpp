/*!
 * @file ARpcModbusRTUMaster.cpp
 * @brief Modbus RTU libary for Arduino. 
 *
 * @copyright   Copyright (c) 2010 DFRobot Co.Ltd (http://www.dfrobot.com)
 * @licence     The MIT License (MIT)
 * @author [Arya](xue.peng@dfrobot.com)
 * @version  V1.0
 * @date  2021-07-16
 * @https://github.com/DFRobot/ARpcModbusRTUMaster
 */
#include <Arduino.h>
#include "ARpcModbusRTUMaster.h"

ARpcModbusRTUMaster::ARpcModbusRTUMaster(ARpcModbusRTUSerial *s)
	:mTimeout(100)
	, mSerial(s)
{
}

void ARpcModbusRTUMaster::setTimeoutTimeMs(uint32_t timeout)
{
	mTimeout=timeout;
}

bool ARpcModbusRTUMaster::readCoil(uint8_t id,uint16_t reg,bool &val)
{
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),0x00,0x01};
	val=false;
	if(id==0||id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return false;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_READ_COILS,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_READ_COILS,1);
	if(mError==eRTU_NO_ERROR&&header)
	{
		if(header->payload[1]&0x01)
			val=true;
		free(header);
		return true;
	}
	return false;
}

bool ARpcModbusRTUMaster::readDiscreteInput(uint8_t id,uint16_t reg,bool &val)
{
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),0x00,0x01};
	val=false;
	if(id==0||id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return false;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_READ_DISCRETE,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_READ_DISCRETE,1);
	if(mError==eRTU_NO_ERROR&&header)
	{
		if(header->payload[1]&0x01)
			val=true;
		free(header);
		return true;
	}
	return false;
}

bool ARpcModbusRTUMaster::readHoldingRegister(uint8_t id,uint16_t reg,uint16_t &val)
{
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),0x00,0x01};
	val=0;
	if(id==0||id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return false;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_READ_HOLDING,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_READ_HOLDING,2);
	if(mError==eRTU_NO_ERROR&&header)
	{
		val=(header->payload[1]<<8)|header->payload[2];
		free(header);
		return true;
	}
	return false;
}

bool ARpcModbusRTUMaster::readInputRegister(uint8_t id,uint16_t reg,uint16_t &val)
{
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),0x00,0x01};
	val=0;
	if(id==0||id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return false;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_READ_INPUT,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_READ_INPUT,2);
	if(mError==eRTU_NO_ERROR&&header)
	{
		val=(header->payload[1]<<8)|header->payload[2];
		free(header);
		return true;
	}
	return false;
}

bool ARpcModbusRTUMaster::writeCoil(uint8_t id,uint16_t reg,bool flag)
{
	uint16_t val=flag?0xFF00:0x0000;
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),(uint8_t)((val>>8)&0xFF),(uint8_t)(val&0xFF)};
	if(id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return 0;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_WRITE_COILS,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_WRITE_COILS,reg);
	if(header)
	{
		//TODO val check?
		free(header);
	}
	return mError==eRTU_NO_ERROR;
}

bool ARpcModbusRTUMaster::writeHoldingRegister(uint8_t id,uint16_t reg,uint16_t val)
{
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),(uint8_t)((val>>8)&0xFF),(uint8_t)(val&0xFF)};
	if(id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return 0;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_WRITE_HOLDING,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_WRITE_HOLDING,reg);
	if(header)
	{
		//TODO val check?
		free(header);
	}
	return mError==eRTU_NO_ERROR;
}

bool ARpcModbusRTUMaster::readMultiCoils(uint8_t id,uint16_t reg,uint16_t count,bool *data)
{
	uint8_t length=(count>>3)+((count&7)?1:0);
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),
		(uint8_t)((count>>8)&0xFF),(uint8_t)(count&0xFF)};
	if(id==0||id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return false;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_READ_COILS,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_READ_COILS,length);
	if(mError==eRTU_NO_ERROR&&header)
	{
		if(data!=NULL)
		{
			count=(count>length)?length:count;
			memcpy(data,(uint8_t*)&(header->payload[1]),count);
		}
		free(header);
	}
	return true;
}

bool ARpcModbusRTUMaster::readMultiDiscreteInputs(uint8_t id,uint16_t reg,uint16_t count,bool *data)
{
	uint8_t length=(count>>3)+((count&7)?1:0);
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),
		(uint8_t)((count>>8)&0xFF),(uint8_t)(count&0xFF)};
	if(id==0&&id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return false;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_READ_DISCRETE,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_READ_DISCRETE,length);
	if(mError==eRTU_NO_ERROR&&header)
	{
		if(data!=NULL)
		{
			count=(count>length)?length:count;
			memcpy(data,(uint8_t *)&(header->payload[1]),count);
		}
		free(header);
		return true;
	}
	return false;
}

bool ARpcModbusRTUMaster::readMultiHoldingRegisters(uint8_t id,uint16_t reg,uint16_t count,uint16_t *data)
{
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),
		(uint8_t)((count>>8)&0xFF),(uint8_t)(count&0xFF)};
	if(id==0&&id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return false;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_READ_HOLDING,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_READ_HOLDING,count*2);
	if(mError==eRTU_NO_ERROR&&header)
	{
		if(data!=NULL)
		{
			for(int i=0;i<count;i++)
				data[i]=((header->payload[1+2*i])<<8)|(header->payload[2+2*i]);
		}
		free(header);
		return true;
	}
	return false;
}

bool ARpcModbusRTUMaster::readMultiInputRegisters(uint8_t id,uint16_t reg,uint16_t count,uint16_t *data)
{
	uint8_t temp[]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),
		(uint8_t)((count>>8)&0xFF),(uint8_t)(count&0xFF)};
	if(id==0&&id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return false;
	}
	pRtuPacketHeader_t header=packed(id,eCMD_READ_INPUT,temp,sizeof(temp));
	sendPackage(header);
	header=recvAndParsePackage(id,(uint8_t)eCMD_READ_INPUT,count*2);
	if(mError==eRTU_NO_ERROR&&header)
	{
		if(data!=NULL)
		{
			for(int i=0;i<count;i++)
				data[i]=((header->payload[1+2*i])<<8)|(header->payload[2+2*i]);
		}
		free(header);
		return true;
	}
	return false;
}

/*
 * uint8_t ARpcModbusRTUMaster::writeMultiCoils(uint8_t id,uint16_t reg,uint16_t count,uint8_t *data)
{
	uint16_t length=(count>>3)+((count&7)?1:0);
	uint8_t temp[length+5]={(uint8_t)((reg>>8)&0xFF),(uint8_t)(reg&0xFF),(uint8_t)((count>>8)&0xFF),
		(uint8_t)(count&0xFF),(uint8_t)length};
	if(id==0&&id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return false;
	}
  memcpy(temp+5, data, size);
  pRtuPacketHeader_t header = packed(id, eCMD_WRITE_MULTI_COILS, temp, sizeof(temp));
  sendPackage(header);
  header = recvAndParsePackage(id, (uint8_t)eCMD_WRITE_MULTI_COILS, reg, &ret);
  size = 0;
  if((ret == 0) && (header != NULL)){
    size = (header->payload[2] << 8) | header->payload[3];
    free(header);
  }
  return ret;
}

uint8_t ARpcModbusRTUMaster::writeHoldingRegister(uint8_t id, uint16_t reg, uint16_t *data, uint16_t regNum){
  uint16_t size = regNum * 2;
  uint8_t *pBuf = (uint8_t *)data;
  #if defined(ESP8266)
  uint8_t temp[size + 5];
  temp[0] = (uint8_t)((reg >> 8) & 0xFF);
  temp[1] = (uint8_t)(reg & 0xFF);
  temp[2] = (uint8_t)(((size/2) >> 8) & 0xFF);
  temp[3] = (uint8_t)((size/2) & 0xFF);
  temp[4] = (uint8_t)size;
  #else
  uint8_t temp[size + 5] = {(uint8_t)((reg >> 8) & 0xFF), (uint8_t)(reg & 0xFF), (uint8_t)(((size/2) >> 8) & 0xFF), (uint8_t)((size/2) & 0xFF),(uint8_t)size};
  #endif
  uint8_t ret = 0;
  if(id > 0xF7){
    RTU_DBG("Device id error");
    return (uint8_t)eRTU_ID_ERROR;
  }
  //memcpy(temp+5, data, size);
  for(int i = 0; i < regNum; i++){
    temp[5+i*2] =  pBuf[2*i + 1];
    temp[6+i*2] =  pBuf[2*i] ;
  }
  pRtuPacketHeader_t header = packed(id, eCMD_WRITE_MULTI_HOLDING, temp, sizeof(temp));
  sendPackage(header);
  header = recvAndParsePackage(id, (uint8_t)eCMD_WRITE_MULTI_HOLDING, reg, &ret);
  size = 0;
  if((ret == 0) && (header != NULL)){
    size = (header->payload[2] << 8) | header->payload[3];
    free(header);
  }
  return ret;
}
*/

ARpcModbusRTUMaster::pRtuPacketHeader_t ARpcModbusRTUMaster::packed(
	uint8_t id,eFunctionCommand_t cmd,void *data,uint16_t size)
{
	return packed(id, (uint8_t)cmd, data, size);
}

ARpcModbusRTUMaster::pRtuPacketHeader_t ARpcModbusRTUMaster::packed(
	uint8_t id,uint8_t cmd,void *data,uint16_t size)
{
	mError=eRTU_NO_ERROR;
	pRtuPacketHeader_t header=NULL;
	uint16_t crc=0;
	if((data==NULL)||(size == 0))return NULL;
	if((header=(pRtuPacketHeader_t)malloc(sizeof(sRtuPacketHeader_t)+size))==NULL)
	{
		mError=eRTU_MEMORY_ERROR;
		return NULL;
	}
	header->len=sizeof(sRtuPacketHeader_t)+size-2;
	header->id=id;
	header->cmd=cmd;
	memcpy(header->payload,data,size);
	crc=calculateCRC((uint8_t *)&(header->id),(header->len)-2);
	header->payload[size]=(crc>>8)&0xFF;
	header->payload[size+1]=crc&0xFF;
	return header;
}

void ARpcModbusRTUMaster::sendPackage(pRtuPacketHeader_t header)
{
	clearRecvBuffer();
	if(header!=NULL)
	{
		mSerial->rs485SetTransmit(true);
		mSerial->serialWrite((uint8_t *)&(header->id),header->len);
		mSerial->serialFlush();
		free(header);
		mSerial->rs485SetTransmit(false);
	}
}

ARpcModbusRTUMaster::pRtuPacketHeader_t ARpcModbusRTUMaster::recvAndParsePackage(
	uint8_t id,uint8_t cmd,uint16_t data)
{
	mError=eRTU_NO_ERROR;
	if(id>0xF7)
	{
		mError=eRTU_ID_ERROR;
		return NULL;
	}
	if(id==0)//broadcast, no return data
		return NULL;

	uint8_t head[4]={0,0,0,0};
	uint16_t crc=0;
	pRtuPacketHeader_t header=NULL;
	//uint8_t timeInterMs = 5;

LOOP:
	uint16_t remain,index=0;
	uint32_t time=millis();
	for(int i=0;i<4;)
	{
		if(mSerial->serialAvailable())
		{
			head[index++]=(uint8_t)mSerial->serialRead();
			if((index==1)&&(head[0]!=id))
				index=0;
			else if((index==2)&&((head[1]&0x7F)!=cmd))
				index=0;
			i=index;
			time=millis();
		}
		if((millis()-time)>mTimeout)
			break;
	}

	if(index!=4)
	{
		mError=eRTU_RECV_ERROR;
		return NULL;
	}
	switch(head[1])
	{
	case eCMD_READ_COILS:
	case eCMD_READ_DISCRETE:
	case eCMD_READ_HOLDING:
	case eCMD_READ_INPUT:
		if(head[2]!=(data&0xFF))
		{
			index=0;
			goto LOOP;
		}
		index=5+head[2];
		break;
	case eCMD_WRITE_COILS:
	case eCMD_WRITE_HOLDING:
	case eCMD_WRITE_MULTI_COILS:
	case eCMD_WRITE_MULTI_HOLDING:
		if(((head[2]<<8)|(head[3]))!=data)
		{
			index=0;
			goto LOOP;
		}
		index=8;
		break;
	default:
		index=5;
		break;
	}
	if((header=(pRtuPacketHeader_t)malloc(index+2))==NULL)
	{
		mError=eRTU_MEMORY_ERROR;
		return NULL;
	}
	header->len=index;
	memcpy((uint8_t *)&(header->id),head,4);
	remain=index-4;
	index=2;
	time=millis();
	while(remain)
	{
		if(mSerial->serialAvailable())
		{
			*(header->payload+index)=(uint8_t)mSerial->serialRead();
			index++;
			time=millis();
			remain--;
		}
		if((millis()-time)>mTimeout)
		{
			free(header);
			mError=eRTU_RECV_ERROR;
			return NULL;
		}
	}
	crc=(header->payload[(header->len)-4]<<8)|header->payload[(header->len)-3];

	if(crc!=calculateCRC((uint8_t *)&(header->id),(header->len)-2))
	{
		free(header);
		mError=eRTU_RECV_ERROR;
		return NULL;
	}
	if(head[1]&0x80)
		mError=eRTU_EXCEPTION_SLAVE_FAILURE;
	return header;
}

uint16_t ARpcModbusRTUMaster::calculateCRC(uint8_t *data,uint8_t len)
{
	uint16_t crc=0xFFFF;
	for(uint8_t pos=0;pos<len;pos++)
	{
		crc^=(uint16_t)data[pos];
		for(uint8_t i=8;i!=0;i--)
		{
			if((crc&0x0001)!=0)
			{
				crc>>=1;
				crc^=0xA001;
			}
			else crc>>=1;
		}
	}
	crc=((crc&0x00FF)<<8)|((crc&0xFF00)>>8);
	return crc;
}

void ARpcModbusRTUMaster::clearRecvBuffer()
{
	while(mSerial->serialAvailable())
	{
		mSerial->serialRead();
		delay(2);
	}
}
